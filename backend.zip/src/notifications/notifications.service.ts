import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationType } from '@prisma/client';

// In-app notifications only for now. Push (FCM/APNs) and email delivery are
// separate provider integrations to wire in when Live/Economy ship — this
// service is the single place those will hook into later (create() is the
// seam), so callers elsewhere never talk to a push/email SDK directly.
@Injectable()
export class NotificationsService {
  constructor(private readonly prisma: PrismaService) {}

  create(userId: string, type: NotificationType, payload?: Record<string, unknown>) {
    return this.prisma.notification.create({
      data: { userId, type, payload: payload as any },
    });
  }

  // FOLLOW is the only type anything actually creates right now (see
  // social.service.ts) — its payload is just a raw followerId, useless
  // to show in a UI without a name. Resolved here with the same
  // batch-lookup pattern used everywhere else in this backend
  // (GiftService.ranking, LiveService.findMyWatchHistory) rather than
  // leaving the client to make N follow-up requests for N notifications.
  async list(userId: string, unreadOnly = false) {
    const notifications = await this.prisma.notification.findMany({
      where: { userId, ...(unreadOnly ? { read: false } : {}) },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    const followerIds = notifications
      .filter((n) => n.type === 'FOLLOW')
      .map((n) => (n.payload as any)?.followerId)
      .filter(Boolean);
    if (followerIds.length === 0) return notifications;

    const followers = await this.prisma.user.findMany({
      where: { id: { in: followerIds } },
      select: { id: true, displayName: true },
    });
    const nameById = new Map(followers.map((f) => [f.id, f.displayName]));

    return notifications.map((n) => {
      if (n.type !== 'FOLLOW') return n;
      const followerId = (n.payload as any)?.followerId;
      return { ...n, payload: { ...(n.payload as object), followerDisplayName: nameById.get(followerId) ?? null } };
    });
  }

  async markRead(userId: string, notificationId: string) {
    await this.prisma.notification.updateMany({
      where: { id: notificationId, userId },
      data: { read: true },
    });
    return { read: true };
  }

  async markAllRead(userId: string) {
    await this.prisma.notification.updateMany({
      where: { userId, read: false },
      data: { read: true },
    });
    return { read: true };
  }
}
