import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { WalletService } from '../economy/wallet.service';
import { UserStatus, RoleName, WalletType, LedgerEntryType } from '@prisma/client';

// Daily check-in reward — a real, disclosed formula, not a hidden
// number: 10 coins per streak day, capped at a 7-day streak (70 coins
// max) so the reward doesn't grow unbounded for a very long streak.
function computeCheckInReward(streak: number): bigint {
  return BigInt(10 * Math.min(streak, 7));
}

function toUtcDateKey(d: Date): string {
  return d.toISOString().slice(0, 10); // "YYYY-MM-DD" in UTC
}

@Injectable()
export class UsersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly wallet: WalletService,
  ) {}

  async findMe(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: { roles: true },
    });
    if (!user) throw new NotFoundException();
    const { passwordHash, ...safe } = user;
    return safe;
  }

  // Real referral list — who signed up using this user's code. Only the
  // fields actually needed to show "you referred these people" (not a
  // full user dump) — deliberately not the same shape as findMe().
  async findMyReferrals(userId: string) {
    return this.prisma.user.findMany({
      where: { referredById: userId },
      select: { id: true, displayName: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getCheckInStatus(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { lastCheckInAt: true, checkInStreak: true },
    });
    if (!user) throw new NotFoundException();
    const today = toUtcDateKey(new Date());
    const alreadyCheckedInToday = user.lastCheckInAt ? toUtcDateKey(user.lastCheckInAt) === today : false;
    return {
      streak: user.checkInStreak,
      alreadyCheckedInToday,
      nextRewardCoins: Number(computeCheckInReward(alreadyCheckedInToday ? user.checkInStreak : user.checkInStreak + 1)),
    };
  }

  async checkIn(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { lastCheckInAt: true, checkInStreak: true },
    });
    if (!user) throw new NotFoundException();

    const now = new Date();
    const today = toUtcDateKey(now);
    const yesterday = toUtcDateKey(new Date(now.getTime() - 24 * 60 * 60 * 1000));

    if (user.lastCheckInAt && toUtcDateKey(user.lastCheckInAt) === today) {
      throw new BadRequestException('Already checked in today');
    }

    const continuingStreak = user.lastCheckInAt && toUtcDateKey(user.lastCheckInAt) === yesterday;
    const newStreak = continuingStreak ? user.checkInStreak + 1 : 1;
    const reward = computeCheckInReward(newStreak);

    await this.prisma.user.update({
      where: { id: userId },
      data: { lastCheckInAt: now, checkInStreak: newStreak },
    });

    await this.wallet.credit({
      userId,
      walletType: WalletType.COIN,
      amount: reward,
      ledgerType: LedgerEntryType.BONUS,
      reference: 'daily-check-in',
      idempotencyKey: `check-in-${userId}-${today}`,
    });

    return { streak: newStreak, rewardCoins: Number(reward) };
  }

  // The only self-service profile edit that exists — displayName is
  // genuinely the only field on the User model a user should be able to
  // change themselves (email/phone/countryCode are identity fields,
  // kycVerified/status/roles are admin-controlled). No bio or avatar
  // field exists on the model at all, so this doesn't pretend to support
  // editing either.
  // Accepts either field independently — a user changing just their
  // avatar shouldn't be forced to resend an unchanged displayName, and
  // vice versa. avatarUrl is trusted as already-uploaded (to ImgBB, from
  // the mobile client) rather than a file this endpoint receives itself;
  // this only ever stores the resulting URL string.
  async updateMe(userId: string, updates: { displayName?: string; avatarUrl?: string }) {
    const data: { displayName?: string; avatarUrl?: string | null } = {};

    if (updates.displayName !== undefined) {
      const trimmed = updates.displayName.trim();
      if (!trimmed || trimmed.length < 2 || trimmed.length > 40) {
        throw new BadRequestException('Display name must be between 2 and 40 characters');
      }
      data.displayName = trimmed;
    }

    if (updates.avatarUrl !== undefined) {
      const trimmed = updates.avatarUrl.trim();
      if (trimmed && !/^https?:\/\//.test(trimmed)) {
        throw new BadRequestException('avatarUrl must be a valid http(s) URL');
      }
      data.avatarUrl = trimmed || null;
    }

    if (Object.keys(data).length === 0) {
      throw new BadRequestException('Nothing to update');
    }

    const user = await this.prisma.user.update({ where: { id: userId }, data });
    const { passwordHash, ...safe } = user;
    return safe;
  }

  async setStatus(
    targetUserId: string,
    status: UserStatus,
    actorId: string,
    actorRoles: RoleName[],
  ) {
    const user = await this.prisma.user.update({
      where: { id: targetUserId },
      data: { status },
    });

    // Every sensitive admin action is audited, per spec §56/§94 non-negotiables.
    await this.audit.record({
      actorId,
      actorRole: actorRoles[0],
      action: `user.status.${status.toLowerCase()}`,
      targetType: 'user',
      targetId: targetUserId,
    });

    const { passwordHash, ...safe } = user;
    return safe;
  }

  // No verification provider integrated — this just records the outcome of
  // a KYC check done elsewhere (manual review, a third-party service not
  // yet wired in). Never treat setting this to true as itself a
  // verification step.
  async setKycVerified(targetUserId: string, verified: boolean, actorId: string, actorRoles: RoleName[]) {
    const user = await this.prisma.user.update({
      where: { id: targetUserId },
      data: { kycVerified: verified },
    });

    await this.audit.record({
      actorId,
      actorRole: actorRoles[0],
      action: `user.kyc.${verified ? 'verify' : 'unverify'}`,
      targetType: 'user',
      targetId: targetUserId,
    });

    const { passwordHash, ...safe } = user;
    return safe;
  }
}
