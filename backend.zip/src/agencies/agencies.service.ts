import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { RoleName } from '@prisma/client';

@Injectable()
export class AgenciesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  register(ownerId: string, name: string) {
    return this.prisma.agency.create({ data: { ownerId, name } });
  }

  async approve(agencyId: string, reviewerId: string, reviewerRoles: RoleName[]) {
    const agency = await this.prisma.agency.update({
      where: { id: agencyId },
      data: { status: 'APPROVED' },
    });
    await this.audit.record({
      actorId: reviewerId,
      actorRole: reviewerRoles[0],
      action: 'agency.approve',
      targetType: 'agency',
      targetId: agencyId,
    });
    return agency;
  }

  // Spec §34: "A creator should not belong to multiple agencies
  // simultaneously unless business rules explicitly support it." Enforced
  // here at the application level (see schema comment on AgencyMembership).
  async addCreator(agencyId: string, creatorId: string, commissionBps: number, actorId: string) {
    const agency = await this.prisma.agency.findUnique({ where: { id: agencyId } });
    if (!agency) throw new NotFoundException('Agency not found');
    if (agency.status !== 'APPROVED') throw new BadRequestException('Agency is not approved');
    if (agency.ownerId !== actorId) throw new ForbiddenException('Only the agency owner can recruit creators');

    const activeElsewhere = await this.prisma.agencyMembership.findFirst({
      where: { creatorId, status: 'ACTIVE' },
    });
    if (activeElsewhere) throw new BadRequestException('Creator already has an active agency membership');

    return this.prisma.agencyMembership.create({
      data: { agencyId, creatorId, commissionBps },
    });
  }

  async removeCreator(agencyId: string, creatorId: string, actorId: string) {
    const agency = await this.prisma.agency.findUnique({ where: { id: agencyId } });
    if (!agency) throw new NotFoundException('Agency not found');
    if (agency.ownerId !== actorId) throw new ForbiddenException('Only the agency owner can remove creators');

    await this.prisma.agencyMembership.updateMany({
      where: { agencyId, creatorId, status: 'ACTIVE' },
      data: { status: 'ENDED', endedAt: new Date() },
    });
    return { removed: true };
  }

  listCreators(agencyId: string) {
    return this.prisma.agencyMembership.findMany({ where: { agencyId, status: 'ACTIVE' } });
  }

  // Commission settlement (spec §34 "receive commissions") requires reading
  // gift/creator-earnings ledger entries for each member creator over a
  // period and crediting an AGENCY_EARNINGS wallet with the agency's cut.
  // Not implemented — depends on deciding a settlement cadence (real-time
  // vs. batched daily/weekly) which is a product decision, not a technical
  // default worth guessing here.
}
