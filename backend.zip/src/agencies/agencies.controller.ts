import { Body, Controller, Delete, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { AgenciesService } from './agencies.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { RoleName } from '@prisma/client';

interface AuthedRequest extends Request {
  user: { userId: string; roles: RoleName[]; countryCode: string };
}

@Controller('api/v1/agencies')
@UseGuards(JwtAuthGuard)
export class AgenciesController {
  constructor(private readonly agencies: AgenciesService) {}

  @Post()
  register(@Body('name') name: string, @Req() req: AuthedRequest) {
    return this.agencies.register(req.user.userId, name);
  }

  @Post(':id/approve')
  @UseGuards(RolesGuard)
  @Roles(RoleName.SUPER_ADMIN)
  approve(@Param('id') id: string, @Req() req: AuthedRequest) {
    return this.agencies.approve(id, req.user.userId, req.user.roles);
  }

  @Post(':id/creators/:creatorId')
  addCreator(
    @Param('id') id: string,
    @Param('creatorId') creatorId: string,
    @Body('commissionBps') commissionBps: number,
    @Req() req: AuthedRequest,
  ) {
    return this.agencies.addCreator(id, creatorId, commissionBps, req.user.userId);
  }

  @Delete(':id/creators/:creatorId')
  removeCreator(@Param('id') id: string, @Param('creatorId') creatorId: string, @Req() req: AuthedRequest) {
    return this.agencies.removeCreator(id, creatorId, req.user.userId);
  }

  @Get(':id/creators')
  listCreators(@Param('id') id: string) {
    return this.agencies.listCreators(id);
  }
}
