import { Body, Controller, Get, Param, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { MessagesService } from './messages.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RoleName } from '@prisma/client';

interface AuthedRequest extends Request {
  user: { userId: string; roles: RoleName[]; countryCode: string };
}

@Controller('api/v1/messages')
@UseGuards(JwtAuthGuard)
export class MessagesController {
  constructor(private readonly messages: MessagesService) {}

  @Post()
  send(@Body('recipientId') recipientId: string, @Body('content') content: string, @Req() req: AuthedRequest) {
    return this.messages.send(req.user.userId, recipientId, content);
  }

  @Get('conversations')
  listConversations(@Req() req: AuthedRequest) {
    return this.messages.listConversations(req.user.userId);
  }

  @Get('with/:userId')
  getConversation(@Param('userId') userId: string, @Req() req: AuthedRequest) {
    return this.messages.getConversation(req.user.userId, userId);
  }

  @Patch('with/:userId/read')
  markRead(@Param('userId') userId: string, @Req() req: AuthedRequest) {
    return this.messages.markConversationRead(req.user.userId, userId);
  }
}
