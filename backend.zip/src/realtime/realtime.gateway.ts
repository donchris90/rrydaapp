import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import { ModerationService } from '../moderation/moderation.service';
import { ChatContext } from '@prisma/client';

interface AuthedSocket extends Socket {
  data: { userId?: string };
}

// Channel naming follows spec §66: live:{sessionId}, room:{roomId}.
// Reconnection (spec §67): the client disconnects/reconnects and re-joins
// the channel; this gateway does not replay financial events on reconnect —
// REST endpoints (GET /live, GET /rooms) are the source of truth for
// current state, sockets only carry the live delta from "now".
@WebSocketGateway({ cors: { origin: '*' } }) // tighten origin allowlist before production
export class RealtimeGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;

  // Simple in-memory rate limiter: userId -> timestamps of recent messages.
  // Fine for a single-instance dev setup; move to Redis-backed limiting
  // once this runs across multiple backend instances.
  private messageTimestamps = new Map<string, number[]>();
  private readonly RATE_LIMIT_WINDOW_MS = 10_000;
  private readonly RATE_LIMIT_MAX = 15;

  constructor(
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly prisma: PrismaService,
    private readonly moderation: ModerationService,
  ) {}

  async handleConnection(client: AuthedSocket) {
    try {
      const token = client.handshake.auth?.token as string | undefined;
      if (!token) throw new Error('No token');
      const payload = await this.jwt.verifyAsync(token, {
        secret: this.config.get<string>('JWT_ACCESS_SECRET'),
      });
      client.data.userId = payload.sub;
      // Every authenticated socket joins its own personal room — this is
      // what makes "emit directly to this specific user, wherever they
      // are in the app" possible at all. Before this, the gateway could
      // only broadcast to a room/live *context* someone had explicitly
      // joined; there was no way to reach a user who hadn't joined
      // anything yet, which is exactly what an incoming call needs.
      client.join(`user:${payload.sub}`);
    } catch {
      client.disconnect();
    }
  }

  handleDisconnect(client: AuthedSocket) {
    if (client.data.userId) this.messageTimestamps.delete(client.data.userId);
  }

  @SubscribeMessage('join')
  handleJoin(
    @MessageBody() data: { context: ChatContext; contextId: string },
    @ConnectedSocket() client: AuthedSocket,
  ) {
    client.join(`${data.context}:${data.contextId}`);
    return { joined: true };
  }

  @SubscribeMessage('leave')
  handleLeave(
    @MessageBody() data: { context: ChatContext; contextId: string },
    @ConnectedSocket() client: AuthedSocket,
  ) {
    client.leave(`${data.context}:${data.contextId}`);
    return { left: true };
  }

  @SubscribeMessage('chat:send')
  async handleChat(
    @MessageBody() data: { context: ChatContext; contextId: string; content: string },
    @ConnectedSocket() client: AuthedSocket,
  ) {
    const userId = client.data.userId;
    if (!userId) return { error: 'unauthenticated' };
    if (!this.checkRateLimit(userId)) return { error: 'rate_limited' };
    if (!data.content || data.content.length > 500) return { error: 'invalid_message' };
    if (await this.moderation.isBanned(data.context, data.contextId, userId)) return { error: 'banned' };
    if (await this.moderation.isMuted(data.context, data.contextId, userId)) return { error: 'muted' };

    const message = await this.prisma.chatMessage.create({
      data: { context: data.context, contextId: data.contextId, senderId: userId, content: data.content },
    });

    this.server.to(`${data.context}:${data.contextId}`).emit('chat:message', {
      id: message.id,
      senderId: message.senderId,
      content: message.content,
      createdAt: message.createdAt,
    });

    return { sent: true };
  }

  // Called by GiftService's controller layer to broadcast a gift event —
  // keeps GiftService itself transport-agnostic.
  broadcastGift(context: ChatContext, contextId: string, payload: unknown) {
    this.server.to(`${context}:${contextId}`).emit('gift:sent', payload);
  }

  broadcastPkScore(pkBattleId: string, payload: unknown) {
    this.server.to(`pk:${pkBattleId}`).emit('pk:score', payload);
  }

  // The actual point of the personal-room change above — emits directly
  // to one specific user's connected socket(s), regardless of what
  // room/live context they're currently in or whether they're in any at
  // all. Used by CallsService for real, instant call signaling
  // (incoming/accepted/declined/ended) rather than something polled.
  emitToUser(userId: string, event: string, payload: unknown) {
    this.server.to(`user:${userId}`).emit(event, payload);
  }

  private checkRateLimit(userId: string): boolean {
    const now = Date.now();
    const timestamps = (this.messageTimestamps.get(userId) ?? []).filter(
      (t) => now - t < this.RATE_LIMIT_WINDOW_MS,
    );
    if (timestamps.length >= this.RATE_LIMIT_MAX) {
      this.messageTimestamps.set(userId, timestamps);
      return false;
    }
    timestamps.push(now);
    this.messageTimestamps.set(userId, timestamps);
    return true;
  }
}
