import { BadRequestException, Body, Controller, Get, Post, Query, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { v4 as uuid } from 'uuid';
import { WalletService } from './wallet.service';
import { CoinPurchaseService } from './coin-purchase.service';
import { GiftService } from './gift.service';
import { PrismaService } from '../prisma/prisma.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { WalletType, RoleName, ChatContext } from '@prisma/client';
import { formatMinorUnits } from '../config/currency.util';
import { RealtimeGateway } from '../realtime/realtime.gateway';

interface AuthedRequest extends Request {
  user: { userId: string; roles: RoleName[]; countryCode: string };
}

@Controller('api/v1/wallet')
@UseGuards(JwtAuthGuard)
export class WalletController {
  constructor(private readonly wallet: WalletService) {}

  @Get()
  async balances(@Req() req: AuthedRequest) {
    const [coin, earnings] = await Promise.all([
      this.wallet.getBalance(req.user.userId, WalletType.COIN),
      this.wallet.getBalance(req.user.userId, WalletType.CREATOR_EARNINGS),
    ]);
    return { coin: coin.toString(), creatorEarnings: earnings.toString() };
  }
}

@Controller('api/v1/coins')
@UseGuards(JwtAuthGuard)
export class CoinPurchaseController {
  constructor(
    private readonly coinPurchase: CoinPurchaseService,
    private readonly prisma: PrismaService,
  ) {}

  @Get('packages')
  async packages(@Query('countryCode') countryCode: string) {
    const rows = await this.prisma.coinPackage.findMany({
      where: { countryCode: countryCode?.toUpperCase(), active: true },
      orderBy: { coinAmount: 'asc' },
    });
    return rows.map((p) => ({
      id: p.id,
      coinAmount: p.coinAmount,
      price: formatMinorUnits(p.priceMinor, p.currencyCode), // client-ready display string, not just the raw minor-unit integer
      priceMinor: p.priceMinor,
      currencyCode: p.currencyCode,
    }));
  }

  // Idempotency-Key should really come from the request header (spec §69);
  // accepting it in the body here for simplicity — move to a header +
  // interceptor once more endpoints need the same treatment.
  @Post('purchase')
  purchase(
    @Body('packageId') packageId: string,
    @Body('idempotencyKey') idempotencyKey: string,
    @Req() req: AuthedRequest,
  ) {
    return this.coinPurchase.initiate(req.user.userId, packageId, idempotencyKey ?? uuid());
  }
}

@Controller('api/v1/gifts')
@UseGuards(JwtAuthGuard)
export class GiftController {
  constructor(
    private readonly gifts: GiftService,
    private readonly realtime: RealtimeGateway,
  ) {}

  // The gift catalog — what a picker UI shows before the user taps one
  // and hits POST /gifts/send with its id. No mobile caller existed for
  // this at all until now; adding it is what makes the in-room Gift
  // button real rather than another placeholder.
  @Get()
  catalog() {
    return this.gifts.catalog();
  }

  // Home's "Honor" ranking banner reads this — real gift totals, see
  // GiftService.ranking for why the window is a lookback, not a
  // calendar-aligned bucket.
  @Get('ranking')
  ranking(@Query('period') period: string | undefined) {
    if (period !== undefined && period !== 'today' && period !== 'week') {
      throw new BadRequestException("period must be 'today' or 'week'");
    }
    return this.gifts.ranking(period ?? 'today');
  }

  @Get('received')
  received(@Req() req: AuthedRequest) {
    return this.gifts.received(req.user.userId);
  }

  @Post('send')
  async send(
    @Body('recipientId') recipientId: string,
    @Body('giftId') giftId: string,
    @Body('context') context: ChatContext | undefined,
    @Body('contextId') contextId: string | undefined,
    @Body('pkBattleId') pkBattleId: string | undefined,
    @Body('idempotencyKey') idempotencyKey: string,
    @Req() req: AuthedRequest,
  ) {
    const transaction = await this.gifts.send({
      senderId: req.user.userId,
      recipientId,
      giftId,
      context,
      contextId,
      pkBattleId,
      idempotencyKey: idempotencyKey ?? uuid(),
    });

    // Was defined on the gateway but never actually called from
    // anywhere — a gift could be sent successfully and no one currently
    // in the room would ever see it happen in real time, despite the
    // broadcast plumbing existing. Only fires when the gift is actually
    // tied to a live room (context+contextId present); a gift sent
    // outside any room has nowhere to broadcast to.
    if (context && contextId) {
      this.realtime.broadcastGift(context, contextId, {
        senderId: req.user.userId,
        recipientId,
        giftId,
        coinAmount: transaction.coinAmount,
      });
    }

    return transaction;
  }
}
