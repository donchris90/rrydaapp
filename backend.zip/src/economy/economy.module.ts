import { Logger, Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { WalletService } from './wallet.service';
import { RevenueSplitService } from './revenue-split.service';
import { CoinPurchaseService, PAYMENT_PROVIDER } from './coin-purchase.service';
import { GiftService } from './gift.service';
import { ChargebackService } from './chargeback.service';
import { WalletController, CoinPurchaseController, GiftController } from './economy.controller';
import { PaymentWebhookController } from './payment-webhook.controller';
import { MockPaymentProvider } from './providers/payment-provider.interface';
import { PaystackPaymentProvider } from './providers/paystack-payment-provider';
import { PrismaService } from '../prisma/prisma.service';
import { RealtimeModule } from '../realtime/realtime.module';

const logger = new Logger('EconomyModule');

@Module({
  imports: [ConfigModule, RealtimeModule],
  providers: [
    WalletService,
    RevenueSplitService,
    CoinPurchaseService,
    GiftService,
    ChargebackService,
    {
      provide: PAYMENT_PROVIDER,
      inject: [ConfigService, PrismaService],
      useFactory: (config: ConfigService, prisma: PrismaService) => {
        if (config.get<string>('PAYSTACK_SECRET_KEY')) {
          return new PaystackPaymentProvider(config, prisma);
        }
        // Loudly logged, not silent — a deployment that meant to be using
        // real payments but has a missing/misspelled env var should never
        // find out by noticing coins appear without anyone actually
        // paying.
        logger.warn(
          'PAYSTACK_SECRET_KEY not set — falling back to MockPaymentProvider. ' +
            'Real payments will NOT work until this is configured.',
        );
        return new MockPaymentProvider();
      },
    },
  ],
  controllers: [WalletController, CoinPurchaseController, GiftController, PaymentWebhookController],
  exports: [WalletService, RevenueSplitService, GiftService, ChargebackService],
})
export class EconomyModule {}
