import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { LiveService } from './live.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RoleName } from '@prisma/client';

interface AuthedRequest extends Request {
  user: { userId: string; roles: RoleName[]; countryCode: string };
}

@Controller('api/v1/live')
@UseGuards(JwtAuthGuard)
export class LiveController {
  constructor(private readonly live: LiveService) {}

  @Get()
  list() {
    return this.live.listLive();
  }

  @Get('mine')
  mine(@Req() req: AuthedRequest) {
    return this.live.findMine(req.user.userId);
  }

  @Get('history')
  history(@Req() req: AuthedRequest) {
    return this.live.findMyWatchHistory(req.user.userId);
  }

  @Post()
  create(
    @Body('title') title: string,
    @Body('category') category: string,
    @Body('themeColor') themeColor: string | undefined,
    @Req() req: AuthedRequest,
  ) {
    return this.live.create(req.user.userId, title, category, req.user.countryCode, themeColor);
  }

  @Post(':id/join')
  join(@Param('id') id: string, @Req() req: AuthedRequest) {
    return this.live.joinToken(id, req.user.userId);
  }

  @Post(':id/end')
  end(@Param('id') id: string, @Req() req: AuthedRequest) {
    return this.live.end(id, req.user.userId);
  }

  // ── Viewer routes (new) ──────────────────────────────────────

  @Get(':id/viewers')
  listViewers(@Param('id') sessionId: string, @Req() req: AuthedRequest) {
    return this.live.listViewers(sessionId, req.user.userId);
  }

  @Post(':id/leave')
  async leave(@Param('id') sessionId: string, @Req() req: AuthedRequest) {
    await this.live.trackViewerLeave(sessionId, req.user.userId);
    return { ok: true };
  }
}