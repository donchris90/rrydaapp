import { BadRequestException, ForbiddenException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { v4 as uuid } from 'uuid';
import { PrismaService } from '../prisma/prisma.service';
import type { RtcProvider } from './providers/rtc-provider.interface';
import { FeatureFlagsService } from '../feature-flags/feature-flags.service';

export const RTC_PROVIDER = 'RTC_PROVIDER';

@Injectable()
export class LiveService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(RTC_PROVIDER) private readonly rtc: RtcProvider,
    private readonly featureFlags: FeatureFlagsService,
  ) {}

  async findMine(hostId: string) {
    return this.prisma.liveSession.findFirst({
      where: { hostId, status: { in: ['SCHEDULED', 'LIVE'] } },
    });
  }

  async create(hostId: string, title: string, category: string | undefined, countryCode: string, themeColor?: string) {
    if (await this.featureFlags.isEnabled('DISABLE_LIVE')) {
      throw new ForbiddenException('Live streaming is temporarily disabled');
    }

    const region = await this.prisma.regionalConfig.findUnique({ where: { countryCode: countryCode.toUpperCase() } });
    if (!region?.active) {
      throw new ForbiddenException('Live streaming is not available in your country yet');
    }

    const existing = await this.prisma.liveSession.findFirst({
      where: { hostId, status: { in: ['SCHEDULED', 'LIVE'] } },
    });
    if (existing) throw new BadRequestException('You already have an active or scheduled live session');

    const sessionId = uuid();
    const { channelName } = await this.rtc.createChannel(sessionId);

    const session = await this.prisma.liveSession.create({
      data: {
        id: sessionId,
        hostId,
        title,
        category,
        countryCode,
        // Only a real hex color is stored — anything else is silently
        // dropped rather than saved as garbage a client would have to
        // guard against when rendering it as a color later.
        themeColor: themeColor && /^#[0-9A-Fa-f]{6}$/.test(themeColor) ? themeColor : null,
        providerChannel: channelName,
        status: 'LIVE',
        startedAt: new Date(),
      },
    });

    const token = await this.rtc.generateToken(channelName, hostId, 'host');
    return { session, token };
  }

  async joinToken(sessionId: string, userId: string) {
    const session = await this.prisma.liveSession.findUnique({ where: { id: sessionId } });
    if (!session || session.status !== 'LIVE') throw new NotFoundException('Live session not found or not active');

    const token = await this.rtc.generateToken(session.providerChannel, userId, 'audience');

    // Record the viewer so the host's gift picker can see them. Added
    // after token generation so a token failure doesn't leave a stale
    // viewer row.
    await this.trackViewerJoin(sessionId, userId);

    return { session, token };
  }

  async end(sessionId: string, hostId: string) {
    const session = await this.prisma.liveSession.findUnique({ where: { id: sessionId } });
    if (!session) throw new NotFoundException('Live session not found');
    if (session.hostId !== hostId) throw new ForbiddenException('Only the host can end this session');

    await this.rtc.destroyChannel(session.providerChannel);

    // Close all open viewer rows — the session is over.
    await this.prisma.liveViewer.updateMany({
      where: { sessionId, leftAt: null },
      data: { leftAt: new Date() },
    });

    return this.prisma.liveSession.update({
      where: { id: sessionId },
      data: { status: 'ENDED', endedAt: new Date() },
    });
  }

  listLive() {
    return this.prisma.liveSession.findMany({
      where: { status: 'LIVE' },
      orderBy: { startedAt: 'desc' },
      take: 50,
    });
  }

  // Real watch history — built from LiveViewer rows that trackViewerJoin
  // has been writing since the join flow first called it, not a new
  // tracking mechanism. One row per session watched (not per join, in
  // case of multiple visits to the same session — most-recent visit
  // wins for ordering). No direct LiveSession->User relation exists for
  // the host, so the host's displayName is a manual batch lookup, same
  // pattern as GiftService.ranking().
  async findMyWatchHistory(userId: string, limit = 50) {
    const viewed = await this.prisma.liveViewer.findMany({
      where: { userId },
      orderBy: { joinedAt: 'desc' },
      take: limit,
      select: { sessionId: true, joinedAt: true },
    });
    if (viewed.length === 0) return [];

    // Collapse to one entry per session (most recent visit), preserving
    // recency order — a session watched multiple times shouldn't crowd
    // out other distinct sessions in the history list.
    const seen = new Set<string>();
    const distinct = viewed.filter((v) => (seen.has(v.sessionId) ? false : (seen.add(v.sessionId), true)));

    const sessions = await this.prisma.liveSession.findMany({
      where: { id: { in: distinct.map((v) => v.sessionId) } },
      select: { id: true, title: true, hostId: true, status: true },
    });
    const sessionById = new Map(sessions.map((s) => [s.id, s]));

    const hosts = await this.prisma.user.findMany({
      where: { id: { in: sessions.map((s) => s.hostId) } },
      select: { id: true, displayName: true },
    });
    const hostById = new Map(hosts.map((h) => [h.id, h]));

    return distinct
      .map((v) => {
        const session = sessionById.get(v.sessionId);
        if (!session) return null; // session deleted since being watched
        const host = hostById.get(session.hostId);
        return {
          sessionId: session.id,
          title: session.title,
          hostDisplayName: host?.displayName ?? null,
          status: session.status,
          watchedAt: v.joinedAt,
        };
      })
      .filter((row): row is NonNullable<typeof row> => row !== null);
  }

  // ── Viewer tracking ────────────────────────────────────────────

  async trackViewerJoin(sessionId: string, userId: string) {
    const session = await this.prisma.liveSession.findUnique({
      where: { id: sessionId },
      select: { id: true, hostId: true, status: true },
    });
    if (!session) throw new NotFoundException('Session not found');
    if (session.status !== 'LIVE') {
      throw new BadRequestException('Session is not live');
    }

    // The host is not a viewer of their own session.
    if (session.hostId === userId) return null;

    // Reuse an existing open row on rejoin (network blip, app reopened)
    // instead of creating a duplicate.
    const existing = await this.prisma.liveViewer.findFirst({
      where: { sessionId, userId, leftAt: null },
    });
    if (existing) return existing;

    return this.prisma.liveViewer.create({
      data: { sessionId, userId },
    });
  }

  async trackViewerLeave(sessionId: string, userId: string) {
    const open = await this.prisma.liveViewer.findFirst({
      where: { sessionId, userId, leftAt: null },
    });
    if (!open) return null;

    return this.prisma.liveViewer.update({
      where: { id: open.id },
      data: { leftAt: new Date() },
    });
  }

  async listViewers(sessionId: string, hostId: string) {
    const session = await this.prisma.liveSession.findUnique({
      where: { id: sessionId },
      select: { hostId: true },
    });
    if (!session) throw new NotFoundException('Session not found');
    if (session.hostId !== hostId) {
      throw new ForbiddenException('Only the host can list viewers');
    }

    const viewers = await this.prisma.liveViewer.findMany({
      where: { sessionId, leftAt: null },
      orderBy: { joinedAt: 'asc' },
      select: {
        userId: true,
        joinedAt: true,
        user: { select: { id: true, displayName: true } },
      },
    });

    return viewers.map((v) => ({
      userId: v.userId,
      displayName: v.user.displayName,
      joinedAt: v.joinedAt,
    }));
  }
}