import { Logger, Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { LiveService, RTC_PROVIDER } from './live.service';
import { LiveController } from './live.controller';
import { MockRtcProvider } from './providers/rtc-provider.interface';
import { AgoraRtcProvider } from './providers/agora-rtc-provider';
import { FeatureFlagsModule } from '../feature-flags/feature-flags.module';

const logger = new Logger('LiveModule');

@Module({
  imports: [FeatureFlagsModule, ConfigModule],
  providers: [
    LiveService,
    {
      provide: RTC_PROVIDER,
      inject: [ConfigService],
      useFactory: (config: ConfigService) => {
        if (config.get<string>('AGORA_APP_ID') && config.get<string>('AGORA_APP_CERTIFICATE')) {
          return new AgoraRtcProvider(config);
        }
        logger.warn(
          'AGORA_APP_ID / AGORA_APP_CERTIFICATE not set — falling back to MockRtcProvider. ' +
            'Live sessions will issue fake tokens no real client can use.',
        );
        return new MockRtcProvider();
      },
    },
  ],
  controllers: [LiveController],
  exports: [LiveService, RTC_PROVIDER],
})
export class LiveModule {}
