import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';

async function bootstrap() {
  // rawBody: true makes req.rawBody (a Buffer) available alongside the
  // normal parsed JSON body — needed because Paystack (and most payment
  // providers) sign the exact raw request bytes for webhook verification.
  // Re-serializing the parsed JSON object would not reliably reproduce the
  // same bytes (key ordering, whitespace), so verifying against anything
  // other than the true raw body is not a real signature check.
  const app = await NestFactory.create(AppModule, { rawBody: true });

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true, // strip unknown fields — clients cannot inject unexpected data (e.g. a balance field)
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  app.enableCors(); // tighten to an explicit allowlist before production

  const port = process.env.PORT ?? 3000;
  await app.listen(port);
  // eslint-disable-next-line no-console
  console.log(`Platform backend listening on port ${port}`);
}
bootstrap();
