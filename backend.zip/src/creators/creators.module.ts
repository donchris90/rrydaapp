import { Module } from '@nestjs/common';
import { CreatorApplicationService } from './creator-application.service';
import { WithdrawalService, PAYOUT_PROVIDER } from './withdrawal.service';
import {
  CreatorsController,
  CreatorApplicationsAdminController,
  WithdrawalsController,
} from './creators.controller';
import { PayoutWebhookController } from './payout-webhook.controller';
import { MockPayoutProvider } from './providers/payout-provider.interface';
import { EconomyModule } from '../economy/economy.module';
import { RiskModule } from '../risk/risk.module';

@Module({
  imports: [EconomyModule, RiskModule],
  providers: [
    CreatorApplicationService,
    WithdrawalService,
    { provide: PAYOUT_PROVIDER, useClass: MockPayoutProvider },
  ],
  controllers: [
    CreatorsController,
    CreatorApplicationsAdminController,
    WithdrawalsController,
    PayoutWebhookController,
  ],
  exports: [CreatorApplicationService, WithdrawalService],
})
export class CreatorsModule {}
