import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { WalletService } from '../economy/wallet.service';
import { AuditService } from '../audit/audit.service';
import { RiskService } from '../risk/risk.service';
import { EXTENDED_TX_OPTIONS } from '../prisma/prisma-transaction-options';
import type { PayoutProvider } from './providers/payout-provider.interface';
import { WalletType, LedgerEntryType, RoleName } from '@prisma/client';

export const PAYOUT_PROVIDER = 'PAYOUT_PROVIDER';

@Injectable()
export class WithdrawalService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly wallet: WalletService,
    private readonly audit: AuditService,
    private readonly risk: RiskService,
    @Inject(PAYOUT_PROVIDER) private readonly payoutProvider: PayoutProvider,
  ) {}

  async request(creatorId: string, amountCoins: number, currencyCode: string, idempotencyKey: string) {
    if (amountCoins <= 0) throw new BadRequestException('Amount must be positive');

    const existing = await this.prisma.withdrawalRequest.findUnique({ where: { idempotencyKey } });
    if (existing) return existing;

    const balance = await this.wallet.getBalance(creatorId, WalletType.CREATOR_EARNINGS);
    if (balance < BigInt(amountCoins)) throw new BadRequestException('Insufficient cleared balance');

    // KYC / payout-account validation are integration points not built here
    // (spec §33) — a real implementation must check both before this line.

    // Computed before the transaction below — a read of existing state
    // (account age, prior withdrawals, etc.), not something this
    // withdrawal's own reserve affects, so it doesn't need to be inside
    // the atomic block.
    const risk = await this.risk.scoreWithdrawal(creatorId, amountCoins);

    // Same fix as EntryService.place()/GiftService.send(): the reserve
    // debit and the WithdrawalRequest record it justifies must commit
    // together. Before this, a failure in withdrawalRequest.create() after
    // a successful reserve debit would leave a creator's earnings debited
    // with no withdrawal record anywhere — real money with no paper trail,
    // the same bug class found live in the game entry flow.
    const withdrawal = await this.prisma.$transaction(async (tx) => {
      // Reserve: debit immediately so the funds can't be double-spent (e.g.
      // via a gift) while the withdrawal is pending review or in flight.
      await this.wallet.debit(
        {
          userId: creatorId,
          walletType: WalletType.CREATOR_EARNINGS,
          amount: BigInt(amountCoins),
          ledgerType: LedgerEntryType.WITHDRAWAL,
          reference: idempotencyKey,
          idempotencyKey: `withdrawal_reserve:${idempotencyKey}`,
        },
        tx,
      );

      return tx.withdrawalRequest.create({
        data: {
          creatorId,
          amountMinor: amountCoins,
          currencyCode,
          status: risk.needsReview ? 'PENDING_REVIEW' : 'APPROVED',
          riskFlags: risk.needsReview ? risk.reasons : undefined,
          idempotencyKey,
        },
      });
    }, EXTENDED_TX_OPTIONS);

    if (!risk.needsReview) {
      await this.processPayout(withdrawal.id);
    }

    return this.prisma.withdrawalRequest.findUniqueOrThrow({ where: { id: withdrawal.id } });
  }

  async approve(withdrawalId: string, reviewerId: string, reviewerRoles: RoleName[]) {
    const withdrawal = await this.prisma.withdrawalRequest.findUnique({ where: { id: withdrawalId } });
    if (!withdrawal) throw new NotFoundException('Withdrawal not found');
    if (withdrawal.status !== 'PENDING_REVIEW') throw new BadRequestException('Not pending review');

    await this.prisma.withdrawalRequest.update({
      where: { id: withdrawalId },
      data: { status: 'APPROVED', decidedAt: new Date() },
    });
    await this.audit.record({
      actorId: reviewerId,
      actorRole: reviewerRoles[0],
      action: 'withdrawal.approve',
      targetType: 'withdrawal',
      targetId: withdrawalId,
    });

    return this.processPayout(withdrawalId);
  }

  async reject(withdrawalId: string, reviewerId: string, reviewerRoles: RoleName[], reason: string) {
    const withdrawal = await this.prisma.withdrawalRequest.findUnique({ where: { id: withdrawalId } });
    if (!withdrawal) throw new NotFoundException('Withdrawal not found');
    if (withdrawal.status !== 'PENDING_REVIEW') throw new BadRequestException('Not pending review');

    // Release + status update commit together — same fix as request()
    // above and every other credit-then-write call site fixed today.
    const updated = await this.prisma.$transaction(async (tx) => {
      await this.releaseReserve(withdrawal.creatorId, withdrawal.amountMinor, withdrawal.idempotencyKey, tx);
      return tx.withdrawalRequest.update({
        where: { id: withdrawalId },
        data: { status: 'REJECTED', decidedAt: new Date(), failureReason: reason },
      });
    }, EXTENDED_TX_OPTIONS);

    await this.audit.record({
      actorId: reviewerId,
      actorRole: reviewerRoles[0],
      action: 'withdrawal.reject',
      targetType: 'withdrawal',
      targetId: withdrawalId,
      metadata: { reason },
    });

    return updated;
  }

  private async processPayout(withdrawalId: string) {
    const withdrawal = await this.prisma.withdrawalRequest.findUniqueOrThrow({ where: { id: withdrawalId } });

    try {
      const payout = await this.payoutProvider.initiatePayout({
        userId: withdrawal.creatorId,
        amountMinor: withdrawal.amountMinor,
        currencyCode: withdrawal.currencyCode,
        idempotencyKey: withdrawal.idempotencyKey,
      });
      return this.prisma.withdrawalRequest.update({
        where: { id: withdrawalId },
        data: { status: 'PROCESSING', payoutProvider: 'mock', providerRef: payout.providerRef },
      });
    } catch (e) {
      // Same fix — release and the FAILED status update commit together.
      return this.prisma.$transaction(async (tx) => {
        await this.releaseReserve(withdrawal.creatorId, withdrawal.amountMinor, withdrawal.idempotencyKey, tx);
        return tx.withdrawalRequest.update({
          where: { id: withdrawalId },
          data: { status: 'FAILED', failureReason: 'Payout initiation failed' },
        });
      }, EXTENDED_TX_OPTIONS);
    }
  }

  // Called from the payout webhook — never from a client call.
  async confirmPaid(providerRef: string) {
    const withdrawal = await this.prisma.withdrawalRequest.findFirst({ where: { providerRef } });
    if (!withdrawal) throw new NotFoundException('Withdrawal not found for providerRef');
    if (withdrawal.status === 'PAID') return withdrawal; // idempotent
    return this.prisma.withdrawalRequest.update({ where: { id: withdrawal.id }, data: { status: 'PAID' } });
  }

  async confirmFailed(providerRef: string, reason: string) {
    const withdrawal = await this.prisma.withdrawalRequest.findFirst({ where: { providerRef } });
    if (!withdrawal) throw new NotFoundException('Withdrawal not found for providerRef');
    if (withdrawal.status === 'FAILED') return withdrawal; // idempotent
    // Same fix — release and the FAILED status update commit together.
    return this.prisma.$transaction(async (tx) => {
      await this.releaseReserve(withdrawal.creatorId, withdrawal.amountMinor, withdrawal.idempotencyKey, tx);
      return tx.withdrawalRequest.update({
        where: { id: withdrawal.id },
        data: { status: 'FAILED', failureReason: reason },
      });
    }, EXTENDED_TX_OPTIONS);
  }

  private async releaseReserve(creatorId: string, amountCoins: number, idempotencyKey: string, tx?: Prisma.TransactionClient) {
    await this.wallet.credit(
      {
        userId: creatorId,
        walletType: WalletType.CREATOR_EARNINGS,
        amount: BigInt(amountCoins),
        ledgerType: LedgerEntryType.WITHDRAWAL_RELEASE,
        reference: idempotencyKey,
        idempotencyKey: `withdrawal_release:${idempotencyKey}`,
      },
      tx,
    );
  }
}
