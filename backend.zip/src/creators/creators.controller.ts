import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { v4 as uuid } from 'uuid';
import { CreatorApplicationService } from './creator-application.service';
import { WithdrawalService } from './withdrawal.service';
import { WalletService } from '../economy/wallet.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { RoleName, WalletType } from '@prisma/client';

interface AuthedRequest extends Request {
  user: { userId: string; roles: RoleName[]; countryCode: string };
}

@Controller('api/v1/creators')
@UseGuards(JwtAuthGuard)
export class CreatorsController {
  constructor(
    private readonly applications: CreatorApplicationService,
    private readonly wallet: WalletService,
  ) {}

  @Post('apply')
  apply(@Req() req: AuthedRequest) {
    return this.applications.apply(req.user.userId);
  }

  @Get('dashboard')
  async dashboard(@Req() req: AuthedRequest) {
    // Live hours, viewers, followers-gained, gift breakdown, and audience
    // country/language (spec §32) need Live + Social event data aggregated
    // over time windows — not built here. This returns the one number that
    // exists today: current withdrawable balance.
    const earnings = await this.wallet.getBalance(req.user.userId, WalletType.CREATOR_EARNINGS);
    return { withdrawableBalance: earnings.toString() };
  }
}

@Controller('api/v1/creators/applications')
@UseGuards(JwtAuthGuard, RolesGuard)
export class CreatorApplicationsAdminController {
  constructor(private readonly applications: CreatorApplicationService) {}

  @Post(':id/approve')
  @Roles(RoleName.SUPER_ADMIN, RoleName.TRUST_SAFETY_ADMIN)
  approve(@Param('id') id: string, @Req() req: AuthedRequest) {
    return this.applications.review(id, true, req.user.userId, req.user.roles);
  }

  @Post(':id/reject')
  @Roles(RoleName.SUPER_ADMIN, RoleName.TRUST_SAFETY_ADMIN)
  reject(@Param('id') id: string, @Body('reason') reason: string, @Req() req: AuthedRequest) {
    return this.applications.review(id, false, req.user.userId, req.user.roles, reason);
  }
}

@Controller('api/v1/withdrawals')
@UseGuards(JwtAuthGuard, RolesGuard)
export class WithdrawalsController {
  constructor(private readonly withdrawals: WithdrawalService) {}

  @Post()
  request(
    @Body('amountCoins') amountCoins: number,
    @Body('currencyCode') currencyCode: string,
    @Body('idempotencyKey') idempotencyKey: string,
    @Req() req: AuthedRequest,
  ) {
    return this.withdrawals.request(req.user.userId, amountCoins, currencyCode, idempotencyKey ?? uuid());
  }

  @Post(':id/approve')
  @Roles(RoleName.SUPER_ADMIN, RoleName.FINANCE_ADMIN)
  approve(@Param('id') id: string, @Req() req: AuthedRequest) {
    return this.withdrawals.approve(id, req.user.userId, req.user.roles);
  }

  @Post(':id/reject')
  @Roles(RoleName.SUPER_ADMIN, RoleName.FINANCE_ADMIN)
  reject(@Param('id') id: string, @Body('reason') reason: string, @Req() req: AuthedRequest) {
    return this.withdrawals.reject(id, req.user.userId, req.user.roles, reason);
  }
}
