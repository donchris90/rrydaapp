import { Body, Controller, Post } from '@nestjs/common';
import { WithdrawalService } from './withdrawal.service';

// Same caveat as the payment webhook: no auth guard because the caller is
// the payout provider, not a user — a real integration must verify the
// webhook signature before trusting payload.status.
@Controller('api/v1/webhooks/payouts')
export class PayoutWebhookController {
  constructor(private readonly withdrawals: WithdrawalService) {}

  @Post()
  async handle(@Body() payload: any) {
    if (payload.status === 'paid') {
      await this.withdrawals.confirmPaid(payload.providerRef);
    } else {
      await this.withdrawals.confirmFailed(payload.providerRef, payload.reason ?? 'Provider reported failure');
    }
    return { received: true };
  }
}
