export interface PayoutProvider {
  initiatePayout(params: {
    userId: string;
    amountMinor: number;
    currencyCode: string;
    idempotencyKey: string;
  }): Promise<{ providerRef: string }>;

  // Real implementations report status asynchronously via webhook, not a
  // synchronous return — this mock simplifies to immediate success for
  // local development only.
  handleWebhook(payload: unknown): Promise<{ providerRef: string; status: 'paid' | 'failed'; reason?: string }>;
}

export class MockPayoutProvider implements PayoutProvider {
  async initiatePayout(params: { idempotencyKey: string }) {
    return { providerRef: `mockpayout_${params.idempotencyKey}` };
  }

  async handleWebhook(payload: any) {
    return { providerRef: payload?.providerRef ?? 'unknown', status: 'paid' as const };
  }
}
