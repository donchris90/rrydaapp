import { Module } from '@nestjs/common';
import { RoomsService } from './rooms.service';
import { RoomsController } from './rooms.controller';
import { ModerationModule } from '../moderation/moderation.module';
import { LiveModule } from '../live/live.module';

@Module({
  imports: [ModerationModule, LiveModule],
  providers: [RoomsService],
  controllers: [RoomsController],
  exports: [RoomsService],
})
export class RoomsModule {}
