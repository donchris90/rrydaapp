import { Module } from '@nestjs/common';
import { PkService } from './pk.service';
import { PkController } from './pk.controller';

@Module({
  providers: [PkService],
  controllers: [PkController],
  exports: [PkService],
})
export class PkModule {}
