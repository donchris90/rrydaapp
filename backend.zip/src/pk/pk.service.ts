import { BadRequestException, ForbiddenException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import type { Queue } from 'bullmq';
import { PK_QUEUE } from '../queue/queue.module';

const COUNTDOWN_MS = 10_000;
const DEFAULT_BATTLE_DURATION_MS = 3 * 60_000;

@Injectable()
export class PkService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(PK_QUEUE) private readonly pkQueue: Queue,
  ) {}

  challenge(challengerId: string, opponentId: string) {
    if (challengerId === opponentId) throw new BadRequestException('Cannot challenge yourself');
    return this.prisma.pKBattle.create({
      data: { challengerId, opponentId, status: 'CHALLENGED' },
    });
  }

  // Without this, a challenged user has no way to ever discover the
  // challenge exists — challenge() doesn't fire a notification, and
  // there was no list endpoint at all. accept() requires already knowing
  // the battle id, which nothing gave the opponent. Ordered most-recent
  // first since a user is very unlikely to have more than a handful of
  // pending challenges at once.
  incomingChallenges(userId: string) {
    return this.prisma.pKBattle.findMany({
      where: { opponentId: userId, status: 'CHALLENGED' },
      orderBy: { createdAt: 'desc' },
    });
  }

  // The missing link this whole feature needed — PKBattle only ever
  // connected two userIds, with no relation to LiveSession at all, so
  // there was previously no way for a viewer watching one host to learn
  // "they're in a PK battle right now, and here's the opponent's live
  // channel to join too." This derives that answer from data that
  // already exists rather than adding a redundant, staleness-prone FK:
  // a battle is truly "live" the moment its status is ACTIVE, and the
  // opponent's current session is whatever LiveSession row currently has
  // status LIVE for their id — both already real, both already correct
  // the instant either changes, with nothing here to keep in sync by hand.
  async findActiveForHost(hostId: string) {
    const battle = await this.prisma.pKBattle.findFirst({
      where: {
        status: 'ACTIVE',
        OR: [{ challengerId: hostId }, { opponentId: hostId }],
      },
      orderBy: { startedAt: 'desc' },
    });
    if (!battle) return null;

    const opponentId = battle.challengerId === hostId ? battle.opponentId : battle.challengerId;
    const opponentSession = await this.prisma.liveSession.findFirst({
      where: { hostId: opponentId, status: 'LIVE' },
      select: { id: true, providerChannel: true, title: true },
    });

    return {
      battle,
      opponentId,
      // null here is a real, meaningful state — the battle is active but
      // the opponent isn't currently broadcasting (they may have
      // disconnected, or the accept happened before either went live).
      // The mobile client should show the clash bar with only the local
      // host's video in that case, not fail outright.
      opponentSession,
    };
  }

  async accept(battleId: string, opponentId: string) {
    const battle = await this.prisma.pKBattle.findUnique({ where: { id: battleId } });
    if (!battle) throw new NotFoundException('Battle not found');
    if (battle.opponentId !== opponentId) throw new ForbiddenException('Only the challenged creator can accept');
    if (battle.status !== 'CHALLENGED') throw new BadRequestException('Battle is not awaiting acceptance');

    const now = new Date();
    const startedAt = new Date(now.getTime() + COUNTDOWN_MS);
    const endsAt = new Date(now.getTime() + COUNTDOWN_MS + DEFAULT_BATTLE_DURATION_MS);

    const updated = await this.prisma.pKBattle.update({
      where: { id: battleId },
      data: { status: 'COUNTDOWN', startedAt, endsAt },
    });

    // If scheduling either job fails (Redis unavailable, this class of
    // BullMQ validation error, etc.), roll the battle back to CHALLENGED
    // rather than leaving it stranded in COUNTDOWN with nothing that will
    // ever move it forward. The opponent can then just accept again. This
    // replaces an earlier version of this comment that claimed the battle
    // "fails loudly rather than silently leaving a battle stuck" — that
    // was aspirational, not actually implemented, and a real bug (BullMQ
    // job IDs can't contain `:`) proved it wrong the first time this ran
    // against live infrastructure.
    try {
      await this.pkQueue.add(
        'activate',
        { battleId },
        { delay: Math.max(startedAt.getTime() - now.getTime(), 0), jobId: `activate-${battleId}` },
      );
      await this.pkQueue.add(
        'settle',
        { battleId },
        { delay: Math.max(endsAt.getTime() - now.getTime(), 0), jobId: `settle-${battleId}` },
      );
    } catch (e) {
      await this.prisma.pKBattle.update({
        where: { id: battleId },
        data: { status: 'CHALLENGED', startedAt: null, endsAt: null },
      });
      throw e;
    }

    return updated;
  }

  // Transitions COUNTDOWN -> ACTIVE once startedAt has passed. In production
  // this is a scheduled job (BullMQ delayed job keyed off startedAt); here
  // it's exposed as an idempotent call so it can be polled or triggered
  // manually until a job queue is wired in.
  async activateIfDue(battleId: string) {
    const battle = await this.prisma.pKBattle.findUnique({ where: { id: battleId } });
    if (!battle) throw new NotFoundException('Battle not found');
    if (battle.status !== 'COUNTDOWN' || !battle.startedAt || battle.startedAt > new Date()) return battle;
    return this.prisma.pKBattle.update({ where: { id: battleId }, data: { status: 'ACTIVE' } });
  }

  // Server-authoritative settlement — the client never determines or
  // displays a winner as final (spec §16). Same "not yet a scheduled job"
  // caveat as activateIfDue.
  async settleIfDue(battleId: string) {
    const battle = await this.prisma.pKBattle.findUnique({ where: { id: battleId } });
    if (!battle) throw new NotFoundException('Battle not found');
    if (battle.status !== 'ACTIVE') return battle;
    if (!battle.endsAt || battle.endsAt > new Date()) return battle; // not over yet

    const winnerId =
      battle.scoreChallenger === battle.scoreOpponent
        ? null // tie — product decision on tie-breaking (sudden death, split reward, etc.) not made here
        : battle.scoreChallenger > battle.scoreOpponent
          ? battle.challengerId
          : battle.opponentId;

    return this.prisma.pKBattle.update({
      where: { id: battleId },
      data: { status: 'SETTLED', settledAt: new Date(), winnerId },
    });
  }

  get(battleId: string) {
    return this.prisma.pKBattle.findUniqueOrThrow({ where: { id: battleId } });
  }
}
