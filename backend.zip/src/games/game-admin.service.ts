import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { GameStatus, RoleName } from '@prisma/client';

@Injectable()
export class GameAdminService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  async setStatus(gameCode: string, status: GameStatus, actorId: string, actorRoles: RoleName[]) {
    const game = await this.prisma.gameDefinition.findUnique({ where: { code: gameCode } });
    if (!game) throw new NotFoundException('Game not found');

    const updated = await this.prisma.gameDefinition.update({ where: { code: gameCode }, data: { status } });

    // Flipping a game to ACTIVE is a legal/compliance decision (spec §96),
    // not a routine toggle — audited distinctly from other config changes.
    await this.audit.record({
      actorId,
      actorRole: actorRoles[0],
      action: `game.status.${status.toLowerCase()}`,
      targetType: 'game_definition',
      targetId: gameCode,
    });

    return updated;
  }

  // Creates a new game or updates an existing one's name/rules — separate
  // from setStatus specifically so changing a game's payout math or dice
  // config is a distinct, audited action from flipping it live. A new game
  // is created DISABLED by default (see the schema default), never active
  // on creation — someone still has to deliberately flip it via setStatus.
  async upsert(
    gameCode: string,
    data: { name: string; minAge?: number; rulesJson?: Record<string, unknown> },
    actorId: string,
    actorRoles: RoleName[],
  ) {
    const game = await this.prisma.gameDefinition.upsert({
      where: { code: gameCode },
      update: { name: data.name, minAge: data.minAge, rulesJson: data.rulesJson as any },
      create: {
        code: gameCode,
        name: data.name,
        minAge: data.minAge ?? 18,
        rulesJson: data.rulesJson as any,
      },
    });

    await this.audit.record({
      actorId,
      actorRole: actorRoles[0],
      action: 'game.upsert',
      targetType: 'game_definition',
      targetId: gameCode,
      metadata: data as any,
    });

    return game;
  }

  async setRegionEnabled(gameCode: string, countryCode: string, enabled: boolean, actorId: string, actorRoles: RoleName[]) {
    const code = countryCode.toUpperCase();
    const region = await this.prisma.gameRegionConfig.upsert({
      where: { gameCode_countryCode: { gameCode, countryCode: code } },
      update: { enabled },
      create: { gameCode, countryCode: code, enabled },
    });

    await this.audit.record({
      actorId,
      actorRole: actorRoles[0],
      action: `game_region.${enabled ? 'enable' : 'disable'}`,
      targetType: 'game_region_config',
      targetId: `${gameCode}:${code}`,
    });

    return region;
  }

  listRegions(gameCode: string) {
    return this.prisma.gameRegionConfig.findMany({ where: { gameCode } });
  }
}
