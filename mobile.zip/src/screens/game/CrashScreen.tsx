import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Svg, { Path, Circle } from 'react-native-svg';
import * as Crypto from 'expo-crypto';
import * as Haptics from 'expo-haptics';
import { useAudioPlayer } from 'expo-audio';
import {
  fetchRounds,
  fetchMyEntries,
  fetchCrashStatus,
  placeEntry,
  cashOutCrash,
  fetchHistory,
  type GameEntry,
} from '../../api/games';
import { fetchWallet } from '../../api/feed';
import { GradientBackground } from '../../components/GradientBackground';
import { PressableScale } from '../../components/PressableScale';
import { colors, radii, spacing, type } from '../../theme';

const GAME_CODE = 'CRASH';

// Crash-specific accent (teal/emerald for the climb, red for the bust) —
// kept local to this screen rather than added to the shared theme, the
// same pattern SumDiceScreen already uses for its own palette. The rest
// of the app stays on the purple/gold system; this screen's identity is
// "rocket climbing a green line," so it borrows that from the web
// reference the user shared, same as the reel/board screen borrowed
// sky-blue for its own identity.
const accent = {
  teal: '#1FD174',
  tealDeep: '#0EA96B',
  tealDim: 'rgba(31, 209, 116, 0.14)',
  gold: colors.gold,
};

// A point actually received from the server — never a computed/faked
// one. The curve below draws a smooth line through these real polled
// values; it is a rendering of real data at 400ms resolution, not a
// second, independent animation pretending to track the round.
interface MultiplierPoint {
  t: number; // seconds since this round went live, from Date.now() at poll time
  m: number; // the real multiplier value returned by CrashService.getStatus at that instant
}

// Curve, countdown, quick-stake buttons, and live payout preview adapted
// from a web reference the user provided — its visual language, not its
// math. That reference generates crashPoint with Math.random() in the
// browser and fabricates a pool of fake bot players; neither made it
// into this screen. Every number here still comes from the real,
// server-authoritative CrashService this project already had.
function MultiplierCurve({ points, isCrashed, width, height }: { points: MultiplierPoint[]; isCrashed: boolean; width: number; height: number }) {
  if (points.length < 2) return null;

  const maxT = Math.max(points[points.length - 1].t, 1);
  const maxM = Math.max(...points.map((p) => p.m), 2) * 1.15;
  const padding = 8;

  const toX = (t: number) => padding + (t / maxT) * (width - padding * 2);
  const toY = (m: number) => height - padding - ((m - 1) / (maxM - 1)) * (height - padding * 2);

  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${toX(p.t).toFixed(1)} ${toY(p.m).toFixed(1)}`).join(' ');
  const fillPath = `${linePath} L ${toX(points[points.length - 1].t).toFixed(1)} ${height - padding} L ${toX(points[0].t).toFixed(1)} ${height - padding} Z`;
  const tip = points[points.length - 1];
  const lineColor = isCrashed ? colors.danger : accent.teal;

  return (
    <Svg width={width} height={height}>
      <Path d={fillPath} fill={lineColor} opacity={0.15} />
      <Path d={linePath} stroke={lineColor} strokeWidth={3} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      {!isCrashed && <Circle cx={toX(tip.t)} cy={toY(tip.m)} r={6} fill="#FFF" />}
      {!isCrashed && <Circle cx={toX(tip.t)} cy={toY(tip.m)} r={11} stroke={lineColor} strokeWidth={2} fill="none" opacity={0.6} />}
    </Svg>
  );
}

// expo-audio players don't reset their own position after finishing —
// seekTo(0) first is what makes a short effect replayable on every tap
// rather than only ever playing once.
function playSound(player: { seekTo: (s: number) => void; play: () => void }) {
  player.seekTo(0);
  player.play();
}

const STAKE_PRESETS = [50, 100, 250, 500];
const AUTO_CASHOUT_PRESETS = [1.2, 1.5, 2.0, 3.0, 5.0, 10.0];

export function CrashScreen() {
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const { width: windowWidth } = useWindowDimensions();
  const chartWidth = Math.max(280, Math.min(windowWidth - 48, 520));
  const queryClient = useQueryClient();
  // useAudioPlayer is a hook — called once at the top level per sound.
  const betPlayer = useAudioPlayer(require('../../../assets/bet.wav'));
  const cashoutPlayer = useAudioPlayer(require('../../../assets/cashout.wav'));
  const crashPlayer = useAudioPlayer(require('../../../assets/crash.wav'));
  const [stake, setStake] = useState('100');
  const [autoCashout, setAutoCashout] = useState('2.00');
  const [autoCashoutOn, setAutoCashoutOn] = useState(false);
  const [now, setNow] = useState(Date.now());
  const historyRef = useRef<MultiplierPoint[]>([]);
  const roundStartRef = useRef<string | null>(null);
  const crashHapticFiredRef = useRef<string | null>(null);

  // Purely cosmetic ticker for the countdown text below — recomputed
  // every 250ms from the round's own real lockAt timestamp, never a
  // second timer pretending to know when the round will actually open.
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(id);
  }, []);

  const roundsQuery = useQuery({
    queryKey: ['games', GAME_CODE, 'rounds'],
    queryFn: () => fetchRounds(GAME_CODE),
    refetchInterval: 3000,
  });
  const currentRound = useMemo(() => {
    const rounds = roundsQuery.data ?? [];
    return rounds.find(
      (round) =>
        round.status === 'SCHEDULED' ||
        round.status === 'OPEN' ||
        round.status === 'LOCKED' ||
        round.status === 'LIVE',
    );
  }, [roundsQuery.data]);

  const currentRoundId = currentRound?.id;
  const roundStatus = currentRound?.status;

  const walletQuery = useQuery({ queryKey: ['wallet'], queryFn: fetchWallet });
  const walletCoins = Number(walletQuery.data?.coin ?? 0);

  const crashStatusQuery = useQuery({
    queryKey: ['games', 'crash-status', currentRoundId],
    queryFn: () => fetchCrashStatus(currentRoundId!),
    enabled: !!currentRoundId,
    refetchInterval: 400,
    retry: 2,
  });

  // Reset the recorded curve whenever a new round starts, and append
  // each real polled point as it arrives.
  useEffect(() => {
    if (roundStartRef.current !== currentRoundId) {
      roundStartRef.current = currentRoundId ?? null;
      historyRef.current = [];
    }
    if (crashStatusQuery.data?.status === 'LIVE' && crashStatusQuery.data.multiplier != null) {
      const t = currentRound?.lockAt ? (Date.now() - new Date(currentRound.lockAt).getTime()) / 1000 : historyRef.current.length * 0.4;
      historyRef.current = [...historyRef.current, { t: Math.max(0, t), m: crashStatusQuery.data.multiplier }].slice(-200);
    }
  }, [crashStatusQuery.data, currentRoundId, currentRound?.lockAt]);

  const myEntriesQuery = useQuery({
    queryKey: ['games', 'myEntries', currentRoundId],
    queryFn: () => fetchMyEntries(currentRoundId!),
    enabled: !!currentRoundId,
    refetchInterval: 3000,
  });
  const myEntry: GameEntry | undefined = myEntriesQuery.data?.[0];

  // A real haptic exactly once per crash, not once per poll — the
  // status stays 'CRASHED' across many subsequent 400ms polls while
  // this screen keeps showing it, so this needs its own one-shot guard
  // rather than firing inline in the render.
  useEffect(() => {
    if (crashStatusQuery.data?.status === 'CRASHED' && currentRoundId && crashHapticFiredRef.current !== currentRoundId) {
      crashHapticFiredRef.current = currentRoundId;
      playSound(crashPlayer);
      if (myEntry?.status === 'PLACED') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      } else {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
      }
    }
  }, [crashStatusQuery.data?.status, currentRoundId, myEntry?.status]);

  const historyQuery = useQuery({
    queryKey: ['games', GAME_CODE, 'history'],
    queryFn: () => fetchHistory(GAME_CODE),
  });

  // Real stats derived from the same settled-round history the chip row
  // renders — an average and a peak of actual crash points, not the
  // static "house edge" / "max profit" marketing copy the web reference
  // hard-codes (this app doesn't expose those as real config anywhere,
  // so nothing here claims a number for them).
  const crashPoints = useMemo(
    () => (historyQuery.data ?? []).map((row) => (row.result as any)?.crashPoint).filter((v): v is number => typeof v === 'number'),
    [historyQuery.data],
  );
  const avgCrash = crashPoints.length ? crashPoints.reduce((a, b) => a + b, 0) / crashPoints.length : null;
  const peakCrash = crashPoints.length ? Math.max(...crashPoints) : null;

  const placeMutation = useMutation({
    mutationFn: () => {
      const stakeAmount = parseInt(stake, 10);
      const autoCashoutMultiplier = autoCashoutOn && autoCashout.trim() ? parseFloat(autoCashout) : undefined;
      return placeEntry(currentRoundId!, {
        selection: [],
        stakeAmount,
        idempotencyKey: Crypto.randomUUID(),
        autoCashoutMultiplier,
      });
    },
    onSuccess: () => {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      playSound(betPlayer);
      queryClient.invalidateQueries({ queryKey: ['games', 'myEntries', currentRoundId] });
      queryClient.invalidateQueries({ queryKey: ['wallet'] });
    },
    onError: (error: any) => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert('Could not place bet', error?.response?.data?.message ?? 'Something went wrong');
    },
  });

  const cashOutMutation = useMutation({
    mutationFn: () => cashOutCrash(currentRoundId!),
    onSuccess: (entry) => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      playSound(cashoutPlayer);
      queryClient.invalidateQueries({ queryKey: ['games', 'myEntries', currentRoundId] });
      queryClient.invalidateQueries({ queryKey: ['wallet'] });
      Alert.alert('Cashed out!', `You won ${entry.rewardAmount.toLocaleString()} coins at ${entry.cashedOutMultiplier}x.`);
    },
    onError: (error: any) => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert('Too late', error?.response?.data?.message ?? "The round already crashed before this reached the server.");
    },
  });

  const crashState = crashStatusQuery.data?.status;
  const isCrashed = crashState === 'CRASHED';
  const isLive =
    crashState === 'LIVE' ||
    (!crashState && (roundStatus === 'LOCKED' || roundStatus === 'LIVE'));
  const isOpen =
    !isLive &&
    !isCrashed &&
    (
      crashState === 'OPEN' ||
      crashState === 'SCHEDULED' ||
      roundStatus === 'OPEN' ||
      roundStatus === 'SCHEDULED'
    );
  const multiplier = crashStatusQuery.data?.multiplier ?? 1.0;
  const canCashOut = isLive && myEntry?.status === 'PLACED' && !isCrashed;
  const alreadyEnteredThisRound = !!myEntry;
  const stakeNum = parseInt(stake, 10) || 0;
  const autoCashoutNum = parseFloat(autoCashout) || 0;
  const livePayout = canCashOut ? Math.floor((myEntry?.coinAmount ?? 0) * multiplier) : 0;
  // Plain arithmetic on the player's own inputs (stake × their chosen
  // auto-cashout target) — a preview of what THEY typed, not a claim
  // about house edge or the round's real odds.
  const estReturn = autoCashoutOn && stakeNum && autoCashoutNum ? Math.floor(stakeNum * autoCashoutNum) : null;
  const estProfit = estReturn != null ? estReturn - stakeNum : null;

  const secondsToLock = currentRound?.lockAt ? Math.max(0, (new Date(currentRound.lockAt).getTime() - now) / 1000) : null;
  const roundTag = currentRoundId ? currentRoundId.slice(-4).toUpperCase() : null;

  const adjustStake = (delta: number) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setStake(String(Math.max(0, stakeNum + delta)));
  };
  const adjustAutoCashout = (delta: number) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setAutoCashout(Math.max(1.01, autoCashoutNum + delta).toFixed(2));
  };

  return (
    <GradientBackground style={{ paddingTop: insets.top }}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: spacing.xl }}>
        <View style={styles.header}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={12} style={styles.backButton}>
            <Ionicons name="arrow-back" size={22} color={colors.textPrimary} />
          </Pressable>
          <View style={styles.titleBlock}>
            <Text style={styles.title}>CRASH</Text>
            <Text style={styles.subtitle}>Watch the rocket climb. Cash out before it crashes.</Text>
          </View>
          <View style={styles.headerRight}>
            <View style={styles.fairBadge}>
              <Ionicons name="shield-checkmark-outline" size={13} color={accent.teal} />
              <Text style={styles.fairBadgeText}>Provably Fair</Text>
            </View>
            {roundTag && <View style={styles.roundBadge}><Text style={styles.roundBadgeText}>#{roundTag}</Text></View>}
          </View>
        </View>

        {crashPoints.length > 0 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.recentRow}>
            {crashPoints.slice(0, 12).map((cp, i) => (
              <View key={i} style={[styles.recentChip, cp >= 2 ? styles.recentChipGood : styles.recentChipBad]}>
                {cp >= 10 && <Text style={styles.recentChipFlame}>🔥</Text>}
                <Text style={styles.recentChipText}>{cp.toFixed(2)}x</Text>
              </View>
            ))}
          </ScrollView>
        )}

        <View style={[styles.multiplierCard, isCrashed && styles.multiplierCardCrashed, isLive && !isCrashed && styles.multiplierCardLive]}>
          <View style={styles.stageHeader}>
            <View>
              <Text style={styles.stageTitle}>LIVE CRASH</Text>
              <Text style={styles.stageSubtitle}>Round {roundTag ? `#${roundTag}` : '—'}</Text>
            </View>
            <View style={[styles.livePill, isLive && styles.livePillActive]}>
              <View style={[styles.liveDot, isLive && styles.liveDotActive]} />
              <Text style={[styles.livePillText, isLive && styles.livePillTextActive]}>{isLive ? 'LIVE' : isCrashed ? 'CRASHED' : 'NEXT'}</Text>
            </View>
          </View>
          {roundsQuery.isLoading ? (
            <View style={styles.stateContainer}>
              <ActivityIndicator color={accent.teal} />
              <Text style={styles.stateTitle}>Loading Crash</Text>
              <Text style={styles.stateText}>Connecting to the next round...</Text>
            </View>
          ) : roundsQuery.isError ? (
            <View style={styles.stateContainer}>
              <Ionicons name="cloud-offline-outline" size={34} color={colors.danger} />
              <Text style={styles.stateTitle}>Unable to load Crash</Text>
              <Text style={styles.stateText}>Check your connection and try again.</Text>
              <Pressable style={styles.retryButton} onPress={() => roundsQuery.refetch()}>
                <Text style={styles.retryButtonText}>TRY AGAIN</Text>
              </Pressable>
            </View>
          ) : !currentRoundId ? (
            <View style={styles.stateContainer}>
              <ActivityIndicator color={accent.teal} />
              <Text style={styles.stateTitle}>Waiting for next round</Text>
              <Text style={styles.stateText}>The next Crash round has not opened yet.</Text>
            </View>
          ) : isCrashed ? (
            <>
              <MultiplierCurve points={historyRef.current} isCrashed width={chartWidth} height={150} />
              <Text style={styles.crashedLabel}>CRASHED AT</Text>
              <Text style={styles.crashedMultiplier}>
                {(
                  currentRound?.result?.crashPoint ??
                  historyRef.current[historyRef.current.length - 1]?.m ??
                  0
                ).toFixed(2)}x
              </Text>
            </>
          ) : isLive ? (
            <>
              <MultiplierCurve points={historyRef.current} isCrashed={false} width={chartWidth} height={150} />
              <Text style={styles.liveLabel}>● LIVE</Text>
              <Text style={styles.multiplierText}>{multiplier.toFixed(2)}x</Text>
              {canCashOut && <Text style={styles.livePayoutText}>Live win: {livePayout.toLocaleString()} coins</Text>}
            </>
          ) : (
            <>
              <View style={styles.waitingRing}>
                <Text style={styles.waitingRingValue}>{secondsToLock != null ? secondsToLock.toFixed(1) : '--'}</Text>
                <Text style={styles.waitingRingUnit}>s</Text>
              </View>
              <Text style={styles.waitingLabel}>NEXT LAUNCH</Text>
              <Text style={styles.waitingText}>Place your bets before blastoff</Text>
            </>
          )}
          <View style={styles.stageFooter}>
            <Text style={styles.stageStat}>SERVER ROUND</Text>
            {avgCrash != null && <Text style={styles.stageStat}>AVG {avgCrash.toFixed(2)}x</Text>}
            {peakCrash != null && <Text style={styles.stageStat}>PEAK {peakCrash.toFixed(2)}x</Text>}
          </View>
        </View>

        {myEntry && (
          <View style={styles.entryStatusCard}>
            <Text style={styles.entryStatusText}>
              {myEntry.status === 'PLACED' && `Bet placed: ${myEntry.coinAmount.toLocaleString()} coins`}
              {myEntry.status === 'WON' && `You won ${myEntry.rewardAmount.toLocaleString()} coins at ${myEntry.cashedOutMultiplier}x`}
              {myEntry.status === 'LOST' && `You lost ${myEntry.coinAmount.toLocaleString()} coins`}
            </Text>
          </View>
        )}

        {canCashOut ? (
          <PressableScale style={styles.cashOutButton} onPress={() => cashOutMutation.mutate()} disabled={cashOutMutation.isPending}>
            <Text style={styles.cashOutText}>
              {cashOutMutation.isPending ? 'Cashing out...' : `CASH OUT · ${livePayout.toLocaleString()} coins`}
            </Text>
          </PressableScale>
        ) : isOpen && !alreadyEnteredThisRound ? (
          <View style={styles.betCard}>
            <View style={styles.betCardHeader}>
            <View>
              <Text style={styles.betCardTitle}>Place Your Bet</Text>
              <Text style={styles.betCardSubtitle}>Choose your stake and cash-out strategy</Text>
            </View>
            <Text style={styles.balancePill}>{walletCoins.toLocaleString()} coins</Text>
          </View>
          <View style={styles.modeTabRow}>
              <Pressable style={[styles.modeTab, !autoCashoutOn && styles.modeTabActive]} onPress={() => setAutoCashoutOn(false)}>
                <Text style={[styles.modeTabText, !autoCashoutOn && styles.modeTabTextActive]}>Manual</Text>
              </Pressable>
              <Pressable style={[styles.modeTab, autoCashoutOn && styles.modeTabActive]} onPress={() => setAutoCashoutOn(true)}>
                <Text style={[styles.modeTabText, autoCashoutOn && styles.modeTabTextActive]}>Auto Cash Out</Text>
              </Pressable>
            </View>

            <View style={styles.betLabelRow}>
              <Text style={styles.betLabel}>Bet Amount (Coins)</Text>
              {walletQuery.data && <Text style={styles.balanceText}>Balance: {walletCoins.toLocaleString()}</Text>}
            </View>
            <View style={styles.stakeRow}>
              <TextInput style={[styles.betInput, { flex: 1 }]} value={stake} onChangeText={setStake} keyboardType="number-pad" />
              <Pressable style={styles.quickButton} onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setStake(String(Math.max(1, Math.floor(stakeNum / 2)))); }}>
                <Text style={styles.quickButtonText}>½</Text>
              </Pressable>
              <Pressable style={styles.quickButton} onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setStake(String(stakeNum * 2)); }}>
                <Text style={styles.quickButtonText}>2X</Text>
              </Pressable>
              {!!walletQuery.data && (
                <Pressable style={[styles.quickButton, styles.maxButton]} onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setStake(String(walletCoins)); }}>
                  <Text style={styles.maxButtonText}>MAX</Text>
                </Pressable>
              )}
            </View>
            <View style={styles.presetRow}>
              {STAKE_PRESETS.map((p) => (
                <Pressable key={p} style={styles.presetChip} onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setStake(String(stakeNum + p)); }}>
                  <Text style={styles.presetChipText}>+{p}</Text>
                </Pressable>
              ))}
            </View>

            <View style={styles.autoCashoutHeader}>
              <Text style={styles.betLabel}>Auto-Cashout</Text>
              <Pressable
                style={[styles.toggle, autoCashoutOn && styles.toggleOn]}
                onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setAutoCashoutOn((v) => !v); }}
              >
                <Text style={[styles.toggleText, autoCashoutOn && styles.toggleTextOn]}>{autoCashoutOn ? 'ON' : 'OFF'}</Text>
              </Pressable>
            </View>
            {autoCashoutOn && (
              <>
                <View style={styles.stakeRow}>
                  <Pressable style={styles.quickButton} onPress={() => adjustAutoCashout(-0.1)}>
                    <Text style={styles.quickButtonText}>-0.1</Text>
                  </Pressable>
                  <TextInput style={[styles.betInput, { flex: 1, textAlign: 'center' }]} value={autoCashout} onChangeText={setAutoCashout} keyboardType="decimal-pad" />
                  <Pressable style={styles.quickButton} onPress={() => adjustAutoCashout(0.1)}>
                    <Text style={styles.quickButtonText}>+0.1</Text>
                  </Pressable>
                </View>
                <View style={styles.presetRow}>
                  {AUTO_CASHOUT_PRESETS.map((p) => (
                    <Pressable key={p} style={styles.presetChip} onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setAutoCashout(p.toFixed(2)); }}>
                      <Text style={styles.presetChipText}>{p.toFixed(2)}x</Text>
                    </Pressable>
                  ))}
                </View>
                {estReturn != null && (
                  <View style={styles.estimateRow}>
                    <Text style={styles.estimateText}>Est. Return: <Text style={styles.estimateValue}>+{estReturn.toLocaleString()}</Text></Text>
                    <Text style={styles.estimateText}>Net Profit: <Text style={styles.estimateValue}>+{estProfit!.toLocaleString()}</Text></Text>
                  </View>
                )}
              </>
            )}

            <PressableScale style={[styles.betButton, !stakeNum && styles.betButtonDisabled]} onPress={() => placeMutation.mutate()} disabled={!stakeNum || placeMutation.isPending}>
              <Text style={styles.betButtonLabel}>{placeMutation.isPending ? 'PLACING BET...' : 'PLACE BET'}</Text>
              {!!stakeNum && (
                <Text style={styles.betButtonSub}>
                  {stakeNum.toLocaleString()} Coins{autoCashoutOn ? ` • Auto @ ${autoCashoutNum.toFixed(2)}X` : ''}
                </Text>
              )}
            </PressableScale>
          </View>
        ) : isOpen && alreadyEnteredThisRound ? (
          <Text style={styles.waitingText}>Bet placed — waiting for the round to start.</Text>
        ) : null}

        <View style={styles.historyHeaderRow}>
          <Text style={styles.historyTitle}>Recent Game History</Text>
          {avgCrash != null && peakCrash != null && (
            <Text style={styles.historyStats}>
              Avg: <Text style={styles.historyStatsValue}>{avgCrash.toFixed(2)}x</Text>  ·  Peak: <Text style={styles.historyStatsValue}>{peakCrash.toFixed(2)}x</Text>
            </Text>
          )}
        </View>
        <View style={styles.historyRow}>
          {(historyQuery.data ?? []).slice(0, 10).map((row) => {
            const crashPoint = (row.result as any)?.crashPoint;
            if (crashPoint == null) return null;
            return (
              <View key={row.roundId} style={[styles.historyChip, crashPoint >= 2 ? styles.historyChipGood : styles.historyChipBad]}>
                {crashPoint >= 10 && <Text style={styles.recentChipFlame}>🔥</Text>}
                <Text style={styles.historyChipText}>{crashPoint.toFixed(2)}x</Text>
              </View>
            );
          })}
        </View>
      </ScrollView>
    </GradientBackground>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.md, paddingBottom: 10 },
  backButton: { padding: spacing.xs, marginRight: 8, backgroundColor: 'rgba(20,23,31,0.82)', borderRadius: 10 },
  titleBlock: { flex: 1 },
  title: { color: '#F4F5F7', fontSize: 16, fontWeight: '900', letterSpacing: 1.2 },
  subtitle: { color: '#737986', fontSize: 9, marginTop: 3 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  fairBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 6, borderRadius: 9, backgroundColor: 'rgba(31,209,116,0.08)', borderWidth: 1, borderColor: 'rgba(31,209,116,0.22)' },
  fairBadgeText: { color: accent.teal, fontSize: 8, fontWeight: '900' },
  roundBadge: { backgroundColor: 'rgba(20,23,31,0.82)', borderRadius: 9, paddingHorizontal: 8, paddingVertical: 6, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)' },
  roundBadgeText: { color: '#B9BDC8', fontSize: 9, fontWeight: '800' },
  recentRow: { paddingHorizontal: spacing.md, gap: 6, paddingBottom: 8 },
  recentChip: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 9, borderWidth: 1 },
  recentChipGood: { backgroundColor: 'rgba(31,209,116,0.09)', borderColor: 'rgba(31,209,116,0.20)' },
  recentChipBad: { backgroundColor: 'rgba(245,73,91,0.09)', borderColor: 'rgba(245,73,91,0.16)' },
  recentChipText: { color: '#EEF0F3', fontWeight: '900', fontSize: 10 },
  recentChipFlame: { fontSize: 10 },
  multiplierCard: { marginHorizontal: 12, marginTop: 6, backgroundColor: '#11141B', borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)', minHeight: 270, overflow: 'hidden' },
  multiplierCardLive: { borderColor: 'rgba(31,209,116,0.32)' },
  multiplierCardCrashed: { borderColor: 'rgba(245,73,91,0.32)' },
  stageHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 15, paddingTop: 13 },
  stageTitle: { color: '#F2F4F7', fontSize: 12, fontWeight: '900', letterSpacing: 1 },
  stageSubtitle: { color: '#666C78', fontSize: 9, marginTop: 3 },
  livePill: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 8, paddingVertical: 5, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.05)' },
  livePillActive: { backgroundColor: 'rgba(31,209,116,0.10)' },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#666C78' },
  liveDotActive: { backgroundColor: accent.teal },
  livePillText: { color: '#737986', fontSize: 8, fontWeight: '900', letterSpacing: 1 },
  livePillTextActive: { color: accent.teal },
  stateContainer: { alignItems: 'center', justifyContent: 'center', paddingHorizontal: spacing.lg, minHeight: 210 },
  stateTitle: { color: '#F4F5F7', fontSize: 15, fontWeight: '800', marginTop: 8, textAlign: 'center' },
  stateText: { color: '#737986', fontSize: 11, marginTop: 4, textAlign: 'center' },
  retryButton: { marginTop: 12, backgroundColor: accent.teal, borderRadius: 10, paddingHorizontal: 18, paddingVertical: 9 },
  retryButtonText: { color: '#07130D', fontSize: 10, fontWeight: '900' },
  liveLabel: { color: accent.teal, fontWeight: '900', letterSpacing: 2, fontSize: 10, marginTop: -6 },
  multiplierText: { color: '#F7F8FA', fontSize: 54, fontWeight: '900' },
  livePayoutText: { color: accent.teal, fontSize: 11, fontWeight: '800', marginTop: 3 },
  crashedLabel: { color: colors.danger, fontWeight: '900', letterSpacing: 2, fontSize: 10, marginTop: -4 },
  crashedMultiplier: { color: colors.danger, fontSize: 40, fontWeight: '900' },
  waitingRing: { width: 92, height: 92, borderRadius: 46, borderWidth: 2, borderColor: 'rgba(31,209,116,0.25)', backgroundColor: 'rgba(31,209,116,0.05)', alignItems: 'center', justifyContent: 'center', flexDirection: 'row' },
  waitingRingValue: { color: '#F5F6F8', fontSize: 25, fontWeight: '900' },
  waitingRingUnit: { color: '#737986', fontSize: 12, fontWeight: '700', marginLeft: 2, marginTop: 6 },
  waitingLabel: { color: '#8A909C', fontWeight: '900', letterSpacing: 2, fontSize: 10, marginTop: 10 },
  waitingText: { color: '#6F7480', fontSize: 10, marginTop: 3, textAlign: 'center' },
  stageFooter: { flexDirection: 'row', alignItems: 'center', gap: 13, paddingHorizontal: 15, paddingVertical: 10, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.06)', marginTop: 5 },
  stageStat: { color: '#686E7A', fontSize: 8, fontWeight: '900' },
  entryStatusCard: { marginHorizontal: 16, marginTop: 9, padding: 10, backgroundColor: 'rgba(31,209,116,0.07)', borderRadius: 11, borderWidth: 1, borderColor: 'rgba(31,209,116,0.16)', alignItems: 'center' },
  entryStatusText: { color: '#DDE1E7', fontSize: 10, fontWeight: '800' },
  cashOutButton: { marginHorizontal: 12, marginTop: 10, backgroundColor: colors.danger, borderRadius: 16, paddingVertical: 14, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cashOutText: { color: '#FFF', fontSize: 18, fontWeight: '900' },
  betCard: { marginHorizontal: 12, marginTop: 10, backgroundColor: '#11141B', borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)', padding: 14 },
  betCardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  betCardTitle: { color: '#F2F4F7', fontSize: 15, fontWeight: '900' },
  betCardSubtitle: { color: '#737986', fontSize: 9, marginTop: 3 },
  balancePill: { color: accent.gold, backgroundColor: 'rgba(255,194,75,0.08)', borderColor: 'rgba(255,194,75,0.18)', borderWidth: 1, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 6, fontSize: 8, fontWeight: '900' },
  modeTabRow: { flexDirection: 'row', backgroundColor: '#0B0E13', borderRadius: 11, padding: 3, marginBottom: 12 },
  modeTab: { flex: 1, paddingVertical: 9, alignItems: 'center', borderRadius: 8 },
  modeTabActive: { backgroundColor: '#20252E' },
  modeTabText: { color: '#626875', fontWeight: '900', fontSize: 9 },
  modeTabTextActive: { color: '#F2F4F7' },
  betLabelRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 },
  betLabel: { color: '#8A909B', fontSize: 9, fontWeight: '900', letterSpacing: 1 },
  balanceText: { color: accent.gold, fontSize: 9, fontWeight: '800' },
  stakeRow: { flexDirection: 'row', gap: 6, marginTop: 7, alignItems: 'center' },
  quickButton: { paddingHorizontal: 10, paddingVertical: 12, backgroundColor: '#1A1E26', borderRadius: 10, borderWidth: 1, borderColor: 'rgba(255,255,255,0.07)' },
  quickButtonText: { color: '#E6E8EC', fontWeight: '900', fontSize: 11 },
  maxButton: { backgroundColor: 'rgba(31,209,116,0.09)', borderColor: 'rgba(31,209,116,0.25)' },
  maxButtonText: { color: accent.teal, fontWeight: '900', fontSize: 10 },
  presetRow: { flexDirection: 'row', gap: 6, marginTop: 7 },
  presetChip: { flex: 1, alignItems: 'center', paddingVertical: 8, backgroundColor: '#171B22', borderRadius: 9, borderWidth: 1, borderColor: 'rgba(255,255,255,0.06)' },
  presetChipText: { color: '#A5AAB4', fontWeight: '800', fontSize: 10 },
  betInput: { backgroundColor: '#0B0E13', borderRadius: 10, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)', padding: 12, color: '#F5F6F8', fontSize: 16, fontWeight: '900' },
  autoCashoutHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 15 },
  toggle: { paddingHorizontal: 9, paddingVertical: 5, borderRadius: 20, backgroundColor: '#1A1E26', borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)' },
  toggleOn: { backgroundColor: 'rgba(31,209,116,0.10)', borderColor: 'rgba(31,209,116,0.30)' },
  toggleText: { color: '#737986', fontWeight: '900', fontSize: 9 },
  toggleTextOn: { color: accent.teal },
  estimateRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 9, padding: 9, borderRadius: 9, backgroundColor: 'rgba(31,209,116,0.05)' },
  estimateText: { color: '#7B818D', fontSize: 10, fontWeight: '700' },
  estimateValue: { color: accent.teal, fontWeight: '900' },
  betButton: { marginTop: 13, backgroundColor: accent.teal, borderRadius: 13, paddingVertical: 13, alignItems: 'center' },
  betButtonDisabled: { opacity: 0.45 },
  betButtonLabel: { color: '#06120B', fontSize: 14, fontWeight: '900', letterSpacing: .5 },
  betButtonSub: { color: 'rgba(6,18,11,0.65)', fontSize: 9, fontWeight: '800', marginTop: 2 },
  historyHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginHorizontal: 16, marginTop: 19, marginBottom: 9 },
  historyTitle: { color: '#F1F3F6', fontSize: 14, fontWeight: '900' },
  historyStats: { color: '#666C78', fontSize: 9, fontWeight: '700' },
  historyStatsValue: { color: '#E7E9ED', fontWeight: '900' },
  historyRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, paddingHorizontal: 16 },
  historyChip: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 9, paddingVertical: 7, borderRadius: 9 },
  historyChipGood: { backgroundColor: 'rgba(31,209,116,0.08)' },
  historyChipBad: { backgroundColor: 'rgba(245,73,91,0.08)' },
  historyChipText: { color: '#E9EBEF', fontWeight: '800', fontSize: 10 },
});
